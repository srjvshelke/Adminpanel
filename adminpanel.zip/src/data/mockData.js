import { tokens } from "../theme";



export const mockDataContacts = [
  {
    id: 1,
    name: "Ragul Sir",
    employeeid:'dewfewfcec',
    email: "Rahul12@gmail.com",
    contact: "1312453354",
    role: "Contractor",
  },
  {
    id: 2,
    name: "suraj shelke",
    employeeid:'dewfewfcec',
    email: "surajw1322@gmail.com",
    contact: "1312453354",
    role: "Contractor",
  },
  {
    id: 3,
    name: "vinit s",
    employeeid:'dewfewfcec',

    email: "vinit2@gmail.com",
    contact: "1312453354",
    role: "Contractor",
  },

];




