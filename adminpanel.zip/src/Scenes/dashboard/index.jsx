
import React, { memo } from 'react'

 function Dashboard() {
  return (
    <>

    </>
  )
}


export default memo(Dashboard);